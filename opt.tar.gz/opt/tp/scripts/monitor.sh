if [ $# -ne 1 ]; then
	echo "use: $0 <nombre_del_proceso>"
	exit 1

fi

proceso="$1"

if pgrep -x "$proceso" >/dev/null; then
	echo "El proceso $proceso esta en ejecucion"  > /dev/null
else
	echo "El proceso $proceso no esta en ejecucion. Enviando correo"
	email_subject="Alerta: Proceso $proceso no esta en ejecucion"
	email_body="El proceso $proceso no esta en ejecucion"

	echo "$email_body" | mutt -s "$email_subject" root

	echo "Se ha enviado una alerta a root" > /dev/null

	echo "correo enviado a root" > /dev/null
fi

