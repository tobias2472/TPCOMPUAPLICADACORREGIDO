#!/bin/bash

write_log() {
	now=$(date +"%T")
	echo "$now - $1|$2" >> /tmp/backup_log.txt
}

enviar_correo() {
	local subject="$1"
	local body="$2"
	echo "$body" | mutt -s "$subject" root
}

carpeta_origen="$1"
carpeta_destino="$2"
nombre=$3
fecha=$(date "+%Y$m$d")

if [ "$carpeta_origen" == "-h" ]; then

	echo "script de backup"

else
	if [ -d "$carpeta_origen" ]; then
		if [ -d "$carpeta_destino" ]; then
			tar -cf "${nombre}backup${fecha}.tar" "$carpeta_origen"
			gzip "${nombre}backup${fecha}.tar"
			mv "${nombre}backup${fecha}.tar.gz" "$carpeta_destino"
		
			enviar_correo "$nombre Respaldado" " $carpeta_origen Respaldado."
			
			echo "${carpeta_origen} Respaldado"
		else
			mensaje_error="$carpeta_destino no montado."
			enviar_correo "No respaldado" "$mensaje_error"
			echo "$mensaje_error"
		fi
	else 
		mensaje_error="$carpeta_origen no aparece."
		enviar_correo "No respaldado" "$mensaje_error"
		echo "$mensaje_error"
	fi
fi

write_log "$carpeta_origen Respaldado"

echo "${carpeta_origen} Respaldado."

cat /tmp/backup_log.txt | mail -s "Log de Respaldo" root

> /tmp/backup_log.txt
